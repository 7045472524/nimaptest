package com.nimap.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimap.app.model.Product;
import com.nimap.app.repo.ProductRepo;

@Service
public class ProductService {
	
	@Autowired
	ProductRepo repo;
	
	
	/**
	 * creating single resource.resource means object
	 * @param obj
	 * @return
	 */
	public Product addProduct(Product obj) { 
		
		return repo.save(obj);
	}
	
	/**
	 * creating list of resources (multiple objects) 
	 * @param obj
	 * @return
	 */
	public List<Product> addProducts(List<Product> obj){
		return repo.saveAll(obj);
	}
	

	
	/**
	 * retrieving / reading resource or resources by id
	 * @param id
	 * @return
	 */
	public Product findProduct(Integer id) {
		
		
		return repo.findById(id).orElse(new Product());
		
		}
	
	
	
    /**
     * retrieving / reading resource  or resources by name.it is optional
     * @param name
     * @return
     */
	public List<Product> getProductByName(String name){
		return repo.findByName(name);
	}
	
	
	
	/**
	 * retrieving / reading list of resources
	 * @return
	 */
	public List<Product> showProduct(){
		return repo.findAll();
	}
	
	
    /**
     * updating resource
     * @param obj
     * @return
     */
	public Product updateProduct(Product obj) {
		
		Product exObj=repo.findById(obj.getPid()).orElse(new Product());//update operation
		exObj.setName(obj.getName());
		exObj.setRegister_date(obj.getRegister_date());
		exObj.setUpdate_date(obj.getUpdate_date());
	    return repo.save(exObj);
		
		
	}
	
	/**
	 *deleting resource or resources by id 
	 * @param id
	 * @return
	 */
	public String deleteProduct(Integer id) {
		
		 repo.deleteById(id);
		return "DELETED SUCCESSFULLY";
	}

}
