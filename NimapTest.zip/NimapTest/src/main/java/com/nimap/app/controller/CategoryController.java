package com.nimap.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nimap.app.model.Category;
import com.nimap.app.service.CategoryService;


@RestController
public class CategoryController {
	
	@Autowired
	CategoryService service;
	
	
	
	
	@PostMapping("/newCategory")
	public Category NewCategory(@RequestBody Category obj) {
		
	return service.addCategory(obj);	
	}
	
	@PostMapping("/newCategories")
	public List<Category> NewCategories(@RequestBody List<Category> obj) {
		
	return service.addCategories(obj);	
	}
	
	
	
	@GetMapping("/allCategories2/{id}")
	public Category allCategories2(@PathVariable Integer id){
		
		return service.findCategory(id);
	}
	
	
	@GetMapping("/getCategoryName/{name}")
	public List<Category> getCategoryName(@PathVariable String name){
		return service.getCategoryByName(name);
	}
	
	@GetMapping("/allCategories")
	public List<Category> allCategories(){
		
		return service.showCategory();
	}
	
	
	
	@PutMapping("/updateCategory")
	public Category updateCategoryBy(@RequestBody Category obj) {
		return service.updateCategory(obj);
	}
	
	@DeleteMapping("/deleteCategory/{id}")
	public String deleteByID(@PathVariable Integer id) {
		return service.deleteCategory(id);
	}
	

}
