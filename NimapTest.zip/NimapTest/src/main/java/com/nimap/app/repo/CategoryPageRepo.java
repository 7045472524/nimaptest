package com.nimap.app.repo;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.nimap.app.model.Category;



public interface CategoryPageRepo extends JpaRepository<Category,Integer>, PagingAndSortingRepository<Category, Integer> {
	

}
