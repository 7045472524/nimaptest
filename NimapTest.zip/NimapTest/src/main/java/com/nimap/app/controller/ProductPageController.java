package com.nimap.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.nimap.app.model.PageResponse;
import com.nimap.app.model.Product;
import com.nimap.app.service.ProductPageService;


@RestController
@RequestMapping("/products")
public class ProductPageController {

    @Autowired
    private ProductPageService productService;
    
    
    @GetMapping("/")
    public PageResponse<Product> getProducts(
            @RequestParam Integer pageIndex,
            @RequestParam Integer pageSize,
            @RequestParam  String sortBy
    ) {
        Page<Product> page = productService.getProductsByPage(pageIndex, pageSize, sortBy);
        return new PageResponse<>(page);
    }

    @PostMapping("/")
    public Product addProduct(@RequestBody Product product) {
        return productService.addProduct(product);
    }


}
