package com.nimap.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.nimap.app.model.Product;
import com.nimap.app.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService service;
	
	@PostMapping("/newProduct")// creating single resource (single object)
	public Product NewProduct(@RequestBody Product obj) {
		
	return service.addProduct(obj);	
	}
	
	@PostMapping("/newProducts")// creating list of resources (multiple objects) 
	public List<Product> NewProducts(@RequestBody List<Product> obj) {
		
	return service.addProducts(obj);	
	}
	
	
	
	@GetMapping("/allProducts/{id}")//retrieving / reading resource or resources by id
	public Product allProducts2(@PathVariable Integer id){
		
		return service.findProduct(id);
	}
	
	
	@GetMapping("/getEmpName/{name}")//retrieving / reading resource  or resources by name
	public List<Product> getProductName(@PathVariable String name){
		return service.getProductByName(name);
	}
	
	@GetMapping("/allProducts")//retrieving / reading list of resources
	public List<Product> allProducts(){
		
		return service.showProduct();
	}
	
	
	
	@PutMapping("/updateProduct")//updating resource
	public Product updateProductBy(@RequestBody Product obj) {
		return service.updateProduct(obj);
	}
	
	@DeleteMapping("/deleteProduct/{id}")// deleting resource or resources by id
	public String deleteByID(@PathVariable Integer id) {
		return service.deleteProduct(id);
	}

}
