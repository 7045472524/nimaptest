package com.nimap.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NimapTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(NimapTestApplication.class, args);
		System.out.println("Application Started...");
	}

}
