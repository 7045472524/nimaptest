package com.nimap.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nimap.app.model.Category;
import com.nimap.app.repo.CategoryRepo;

@Service
public class CategoryService {
	
	@Autowired
	CategoryRepo repo;
	
	/**
	 * creating single resource.resource means object
	 * @param obj
	 * @return
	 */
	public Category addCategory(Category obj) { 
		return repo.save(obj);
	}
	
	
	/**
	 * creating list of resources (multiple objects) 
	 * @param obj
	 * @return
	 */
	public List<Category> addCategories(List<Category> obj){
		return repo.saveAll(obj);
	}
	

	/**
	 * retrieving / reading resource or resources by id
	 * @param id
	 * @return
	 */
	public Category findCategory(Integer id) {//retrieving / reading resource or resources by id
		
		
		return repo.findById(id).orElse(new Category());
		
		}

	
	
	
	/**
	 * retrieving / reading resource  or resources by name.it is optional
	 * @param name
	 * @return
	 */
	public List<Category> getCategoryByName(String name){
		return repo.findByName(name);
	}
	
	
	/**
	 * retrieving / reading list of resources
	 * @return
	 */
	public List<Category> showCategory(){
		return repo.findAll();
	}
	
	
    /**
     * updating resource
     * @param obj
     * @return
     */
	public Category updateCategory(Category obj) {
		
		Category exObj=repo.findById(obj.getCid()).orElse(new Category());//update operation
		exObj.setName(obj.getName());
		exObj.setRegister_date(obj.getRegister_date());
		exObj.setUpdate_date(obj.getUpdate_date());
		return repo.save(exObj);
		
		
	}
	
	/**
	 * deleting resource or resources by id
	 * @param id
	 * @return
	 */
	public String deleteCategory(Integer id) {
		
		 repo.deleteById(id);
		return "DELETED SUCCESSFULLY";
	}

}
